import UIKit

/*
// ----- #11 매개변수로서 클로저 -----

// () -> Void
// func completion(){}
 
// completion 이라는 클로저를 매개변수로 가지는
// 메소드 정의
func sayHi(completion:() -> Void){
    print("sayHi() called")
    sleep(1) // 1초 잠깐 멈추기
    // completion 클로저 실행
    completion()
}

// 메소드 호출부에서 이벤트 종료를 알 수 있다
sayHi(completion: {
    print("1초가 지났다. 1")
})

sayHi() {
    print("1초가 지났다. 2")
}

sayHi {
    print("1초가 지났다. 3")
}
 
// (Stirng) -> Void
// func completion(userInput: String){}

// 매개변수로서 데이터를 반환하는 클로저
func sayHiWithName(completion: (String)-> Void){
    print("sayHiWithName() called")
    sleep(1)
    //클로저를 실행과 동시에 데이터를 반환
    completion("안녕^^")
}

sayHiWithName(completion: { (comment: String) in
    print ("(1) 1초 뒤에 그가 말했다! comment: ",comment)
})

sayHiWithName(completion: { comment in
    print ("(2) 1초 뒤에 그가 말했다! comment: ",comment)
})

sayHiWithName{ comment in
    print("(3) 1초 뒤에 그가 말했다! comment: ", comment)
}

sayHiWithName{
    print("(4) 1초 뒤에 그가 말했다! comment: ", $0)
}

// (String, String) -> Void
// func completion(first: String, second: String){}

// 매개변수로서 데이터를 여러개 반환하는 클로저
func sayHiWithFullName(completion: (String, String)-> Void){
    print("sayHiWithFullName() called")
    sleep(1)
    //클로저를 실행과 동시에 데이터를 반환
    completion("1월5일", "수요일")
}

sayHiWithFullName{ first, second in
    print("(1) 첫번째: \(first), 두번째: \(second)")
}

sayHiWithFullName{
    print("(2) 첫번쨰: \($0), 두번째: \($1)")
}
 
// _은 생략(안쓰겠다는것) 이라는 의미
 sayHiWithFullName{ _, second in
     print("(3) 두번째: \(second)")
 }


// Completion을 빼고 싶은 경우_ 기본형을 nil로 주기
func sayHiOptional(completion:(() -> Void)? = nil){
    print("sayHiOptional() called")
    sleep(1) // 1초 잠깐 멈추기
    // completion 클로저 실행
    completion?()
}

sayHiOptional()

sayHiOptional(completion: {
    print("1초가 지났다!")
})


// (Int) -> String
//func transform(number: Int) -> String {
//    return "숫자: \(number)"
//}

var myNumbers : [Int] = [0,1,2,3,4,5]
var tranformedmyNumbers = myNumbers.map { aNumber in
    return "숫자: \(aNumber)"
}

var tranformedNumbers = myNumbers.map { (aNumber: Int) -> String in
    return "숫자: \(aNumber)"
}

var transformedNubers = myNumbers.map{
    return "숫자: \($0)"
}

// ----- #12 객체 생성자, 해제자 -----

// 객체 생성자: 메모리에 올린다고 생각하면 됨
class MyFriend {
    var name: String
    init(_ name: String = "이름없음"){
        self.name = name
        print("init()_ MyFriend 가 메모리에 올라갔다", self.name)
    }
    
    deinit{
        print("deinit()_ 메모리에서 사라짐 - ", self.name)
    }
    
    // deinit 검증을 위해 작성
    var calledTimes = 0
    let Max_times = 5
    
    static var instancesOfSelf = [MyFriend]()
    class func destorySelf(object: MyFriend){
        instancesOfSelf = instancesOfSelf.filter{ (aFriend : MyFriend) in
            aFriend !== object
        }
    }
    
    func call(){
        calledTimes += 1
        print("called \(calledTimes)")
        if calledTimes > Max_times{
            MyFriend.destorySelf(object: self)
        }
    }
}

let myFriend = MyFriend("김하경")
let aFriend = MyFriend()

// Unmanaged.passUnretained(객체).toOpaque()
// 로 해당 객체의 메모리 주소를 프린트 할 수 있습니다.
let anObjectMemoryAddress = Unmanaged.passUnretained(aFriend).toOpaque()
let secondMemoryAddress = Unmanaged.passUnretained(myFriend).toOpaque()

print(anObjectMemoryAddress)
print(secondMemoryAddress)

weak var aFriendToBeDestoried = MyFriend("개발하는 김하경")

if aFriendToBeDestoried != nil{
    aFriendToBeDestoried!.call() // 자동으로 메모리 날림
} else{
    print("객체가 더 이상 메모리에 없습니다.")
}

// ----- #13 상속 -----

class Friend{
    var name: String
    
    init(_ name: String){
        self.name = name
    }
    
    func sayHi(){
        print("안녕? 난 \(self.name) 이라고 해!")
    }
}

class BestFriend: Friend{
    
    // override 로 부모의 메소드를 가져왔다
    override init(_ name: String) {
        // super 로 부모의 메소드 사용
        super.init("베프 " + name)
    }
    
    override func sayHi() {
        super.sayHi()
    }
}

let myFriend = Friend("김하경")
myFriend.sayHi()

let myBestFriend = BestFriend("애플")
myBestFriend.sayHi()

myBestFriend.name

// ----- #14 딕셔너리 -----

// 키 : 값
var myFriends = ["bestFriend": "하경",
                 "highschool": "애플"]

let myBestFriend = myFriends["bestFriend"]
let highSchoolFriend = myFriends["highschool"]
let youtunerFriend = myFriends["youtube",default: "친구없음"]

myFriends["bestFriend"] = "개발하는 김하경"
let myBF = myFriends["bestFriend"]

myFriends["newfriend"] = "삼성"
let newfriend = myFriends["newfriend"]

myFriends.updateValue("엘지", forKey: "exfriend")
let exfriend = myFriends["exfriend"]

myFriends.updateValue("샤오미", forKey: "exfriend")
let exfriend2 = myFriends["exfriend"]

// 빈 딕셔너리 만들기
// let emptyDictionary: [String : Int] = [:]
let emptyDictionary = [String : Int]()
let myEmptyDictionary : [String : Int] = Dictionary<String, Int>()

myFriends.count

for item in myFriends{
    print("item: ",item)
}

*/

// ----- #15 파이널 클래스 -----

// final 은 상속을 못하게 함
final class Friend{
    var name: String
    
    init(name: String){
        self.name = name
    }
}

/*
class BestFriend: Friend{

    override init(name: String) {
        super.init(name: "베프 "+name)
    }
}

let myFriend = Friend(name: "김하경")
let myBestFriend = BestFriend(name: "애플")
*/
