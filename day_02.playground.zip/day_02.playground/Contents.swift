import UIKit
/*
// ----- #6 클래스 vs 스트럭트 -----

// 유튜버 (데이터) 모델 - struct/구조체
struct YoutuberStruct{
    var name: String
    var subscribersCount: Int
}

var devKim = YoutuberStruct(name:"김하경", subscribersCount: 99999)
var devKimClone = devKim
print("값 넣기 전 devJeongClone.name: \(devKimClone.name)")

devKimClone.name = "김하하하"

// 값 복사이기 떄문에 둘의 값이 다르다
print("값 넣은 후 devKimClone.name: \(devKimClone.name)")
print("값 넣은 후 devKim.name: \(devKim.name)")

// 클래스
class YoutuberClass{
    var name: String
    var subscribersCount: Int
    // 생성자 - 즉 메모리에 올린다
    // init으로 매개변수를 가진 생성자 메소드를 만들어야
    // 매개변수를 넣어서 그 값을 가진 객체(object)를 만들 수 있다.
    init(name: String, subscriberCount:Int){
        self.name = name
        self.subscribersCount = subscriberCount
    }
}

var jeongDaeRi = YoutuberClass(name: "정대리", subscriberCount: 99999)
var jeongDaeRiClone = jeongDaeRi
print("값 넣기 전 jeongDaeRiClone.name: \(jeongDaeRiClone.name)")

jeongDaeRiClone.name = "호롤롤롤로"

print("값 넣은 후 jeongDaeRiClone.name: \(jeongDaeRiClone.name)")
print("값 넣은 후 jeongDaeRi.name: \(jeongDaeRi.name)")

// ----- #7 프로퍼티 옵저버 -----
var myAge = 0{
    willSet{
        print("값이 설정될 예정이다. myAge: \(myAge)")
    }
    didSet{
        print("값이 설정되었다. myAge:\(myAge)")
    }
}

myAge = 10
myAge = 20



// ----- #8 함수 매개변수 이름 -----

// 함수, 메소드 정의
func myFunction(name:String)-> String{
    return "안녕하세요?! \(name) 입니다!"
}

// 함수, 메소드를 호출한다. call
myFunction(name: "김하경")

// 함수, 메소드 정의
func myFunctionSecond(with name:String)-> String{
    return "안녕하세요?! \(name) 입니다!"
}

myFunctionSecond(with: "김하하하")

// 함수, 메소드 정의
func myFunctionThird(_ name:String)-> String{
    return "안녕하세요?! \(name) 입니다!"
}

myFunctionThird("경")

// ----- #9 제네릭 -----

struct MyArray<T>{
    
    // 제네릭을 담은 빈 배열
    var elements: [T] = [T]()
    
    //생성자
    init(_ elements: [T]){
        self.elements = elements
    }
}

struct Friend {
    var name: String
}

struct PpakkCoder {
    var name: String
}

var mySomeArray = MyArray([1,2,3])
print("mySomeArray: \(mySomeArray)")

var myStringArray = MyArray(["가","나","다"])
print("myStringArray: \(myStringArray)")

let friend_01 = Friend(name:"철수")
let friend_02 = Friend(name:"영희")
let friend_03 = Friend(name:"수잔")

var myFrinedsArray = MyArray([friend_01,friend_02,friend_03])
print("myFrinedsArray: \(myFrinedsArray)")

// ----- #10 클로저 -----

// String을 반환하는 클로저
let myName : String = {
    // myName 으로 들어간다
    return "김하경"
}()

print(myName)

// 클로저 정의
let myRealName: (String) -> String = { (name: String) -> String in return "개발하는 \(name)"}

myRealName("김하하하")

let myRealNameLogic : (String) -> Void = {(name: String) in print("개발하는 \(name)")}

myRealNameLogic("경이")
 */

// ----- #11 매개변수로서 클로저 -----

/*
// completion 이라는 클로저를 매개변수로 가지는
// 메소드 정의
func sayHi(completion: () -> Void){
    print("sayHi() called")
    sleep(2) // 2초 잠깐 멈추기
    // completion 클로저 실행
    completion()
}

// 메소드 호출부 에서 이벤트 종료를 알 수 있다.
sayHi(completion: {
    print("2초가 지났다. 1")
})

sayHi() {
    print("2초가 지났다. 2")
}

sayHi{
    print("2초가 지났다. 3")
}

// 매개변수로서 데이터를 반환하는 클로저
func sayHiWithName(completion:(String) -> Void){
    print("sayHiWithName() called")
    sleep(1)
    // 클로저를 실행과 동시에 데이터를 반환
    completion("오늘도 빡코딩 하고 있지?!")
}

sayHiWithName(completion: { (comment: String) in print("(1) 1초 뒤에 그가 말했다! comment: ", comment)})

sayHiWithName(completion: { comment in print("(2) 1초 뒤에 그가 말했다! comment: ", comment)})

sayHiWithName{ comment in print("(3) 1초 뒤에 그가 말했다! comment: ", comment)}

sayHiWithName{
    print("(4) 1초 뒤에 그가 말했다! comment: ", $0)
}

// 매개변수로서 데이터를 여러개 반환하는 클로저
func sayHiWithFullName(completion:(String,String) -> Void){
    print("sayHiWithFullName() called")
    sleep(1)
    // 클로저를 실행과 동시에 데이터를 반환
    completion("김하경","하하하")
}

sayHiWithFullName{ first, second in print("첫번째: \(first), 두번째: \(second)")}

sayHiWithFullName{
    print("첫번째: \($0), 두번째: \($1)")
}
 */

// completion 이벤트를 받기 싫을 때 -> optional로 만들기
func sayHiOptional(completion:(() -> Void)? = nil){
    print("sayHiOptional() called")
    sleep(1)
    // completion 클로저 실행
    completion?()
}

sayHiOptional()

sayHiOptional(completion: {
    print("1초가 지났다..!!")
})
